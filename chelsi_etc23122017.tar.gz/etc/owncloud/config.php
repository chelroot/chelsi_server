<?php
$CONFIG = array (
  'instanceid' => '53a3757c1e50d',
  'passwordsalt' => '624879a6d6c68637562afa845a26e2',
  'datadirectory' => '/var/www/webapps/owncloud/data',
  'dbtype' => 'mysql',
  'version' => '5.0.28',
  'dbname' => 'owncloud',
  'dbhost' => 'localhost',
  'dbtableprefix' => 'oc_',
  'dbuser' => 'owncloud',
  'dbpassword' => 'erathahmiedafoop',
  'installed' => true,
);
