# setting default options for minicom (sh)

# color on
MINICOM="$MINICOM -c on"

# 8 bit letters go through 
# (needed for reading/writing some national letters, e.g. Russian)
MINICOM="$MINICOM -8"

export MINICOM
